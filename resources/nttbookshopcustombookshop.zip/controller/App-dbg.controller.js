sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("ntt.bookshop.custombookshop.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  